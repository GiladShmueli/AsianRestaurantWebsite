// Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyB1Jb5YEzpsZNSKknk4ICHUqGFRQydojAo",
    authDomain: "asian-restaurant.firebaseapp.com",
    projectId: "asian-restaurant",
    storageBucket: "asian-restaurant.appspot.com",
    messagingSenderId: "1009981587635",
    appId: "1:1009981587635:web:a26b3ff93b0d823cf430c6",
    measurementId: "G-FS29W3PLN8"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
                firebase.analytics();
                const db = firebase.firestore();
              db.settings({timesnapsInSnapshots: true});