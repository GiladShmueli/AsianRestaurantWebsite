function getDishes() {
    db.collection("dishes").get().then(snapshot => {
        info = [];
        snapshot.docs.forEach(doc => {

            info.unshift({
                name: doc.data().name,
                id: doc.id,
                price: doc.data().price,
                type: doc.data().type
            });

        });
    }).then ( () => {
        renderDishes();
    })
}

function renderDishes() {
    const dishes = document.querySelector("#dishes");
    const drinks = document.querySelector("#drinks");
    info.forEach(element => {
        let menudiv = document.createElement("div");
        menudiv.setAttribute("class", "row");
        let namep = document.createElement("p");
        namep.className = "col-8";
        namep.innerText = element.name;
        let pricep = document.createElement("p");
        pricep.className = "col-2";
        let marg = document.createElement("div");
        marg.className = "col-1";
        pricep.innerText = element.price + shekel;
        menudiv.appendChild(marg);
        menudiv.appendChild(namep);
        menudiv.appendChild(pricep);
        if(element.type=="dish")
            dishes.appendChild(menudiv);
        else
            drinks.appendChild(menudiv);            
    });
}

// function addDish(name, price, type) {
//     db.collection("dishes").add({
//         "name": name,
//         "price": price,
//         "type": type
//     })
//     return `name {name} price {price} type {type}`
// }




function reportWindowSize() {
    const menu = document.querySelector("#menu");
    const dishes = document.querySelector("#dishes");
    const drinks = document.querySelector("#drinks");
    const navs = document.querySelectorAll("a");
    const header = document.querySelector("#header-div");
    if(window.innerWidth <= 500) {
        menu.classList.add("menu-shrinked");
        menu.classList.remove("menu-expanded");
        menu.classList.remove("menu-middled");
        dishes.classList = "menu-column col-12";
        drinks.classList = "menu-column col-12";
        header.className = "header-right";
        navs.forEach( element => {
            element.classList.add("nav-side");
            element.classList.remove("nav-top");
        })
    } else if (window.innerWidth <=970) {
        menu.classList.add("menu-middled");
        menu.classList.remove("menu-shrinked");
        menu.classList.remove("menu-shrinked");
        dishes.classList = "menu-column col-m";
        drinks.classList = "menu-column col-m";
        header.className = "header-top";
        navs.forEach( element => {
            element.classList.add("nav-top");
            element.classList.remove("nav-side");
        })
    }
    else {
        menu.classList.add("menu-expanded");
        menu.classList.remove("menu-shrinked");
        menu.classList.remove("menu-middled");
        dishes.classList = "menu-column col-m";
        drinks.classList = "menu-column col-m";
        header.className = "header-top";
        navs.forEach( element => {
            element.classList.add("nav-top");
            element.classList.remove("nav-side");
        })
    }
}

document.getElementById('order').onclick = function() {
    window.location.href = '/order/';
}


//main (run instantly)
const shekel = "\u20AA";
let info = [];
getDishes();
reportWindowSize();
window.onresize = reportWindowSize;