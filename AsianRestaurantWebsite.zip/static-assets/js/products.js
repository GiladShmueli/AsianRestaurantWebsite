function getDishes() {
    db.collection("dishes").get().then(snapshot => {
        info = [];
        snapshot.docs.forEach(doc => {

            info.unshift({
                name: doc.data().name,
                id: doc.id,
                price: doc.data().price,
                type: doc.data().type,
                image: doc.data().image,
                category: doc.data().category
            });

        });
    }).then ( () => {
        renderDishes();
        let menuboxes = $(".menubox");
        // $(".menubox").on("click", element => {
        //     let dish_image = document.querySelector("#dish-image");
        //     console.log(element.currentTarget.id)
        //     dish_image.setAttribute("src", info.at(element.currentTarget.id).image);
        // });
        // for(let i=0 ; i < menuboxes.length; i++) {
        //     let element = menuboxes[i];
        //     console.log(element);
        //     element.addEventListener("click",() => {
        //         let dish_image = document.querySelector("#dish-image");
        //         dish_image.setAttribute("src", info.at(element.id).image);
        //     })
        // }
    })
}

function renderDishes() {
    const dishes = document.querySelector("#dishes");
    const drinks = document.querySelector("#drinks");
    info.forEach(element => {
        let menudiv = document.createElement("div");
        menudiv.setAttribute("class", "menubox");
        menudiv.setAttribute("id", element.id);
        let namep = document.createElement("p");
        namep.className = "center-text";
        namep.innerText = element.name;
        let img = document.createElement("img");
        img.src = element.image;
        img.className = "menu-img";
        let imgbox = document.createElement("center");
        imgbox.appendChild(img);
        let pricep = document.createElement("p");
        pricep.innerText = element.price + shekel;
        pricep.className = "center-text";
        menudiv.appendChild(namep);
        menudiv.appendChild(imgbox);
        menudiv.appendChild(pricep);
        if(element.type=="dish")
            dishes.appendChild(menudiv);
        else
            drinks.appendChild(menudiv);   
    });
}

function dishByMousePos(event) {
    let x = event.clientX;
    let y = event.clientY;
    let element = document.elementFromPoint(x, y).closest(".menubox");
    let dish_image = document.querySelector("#dish-image");
    if(element != undefined)
        dish_image.setAttribute("src", info.find(dish => dish.id == element.id).image);
    displayChoice();
  }

  function displayChoice() {
      let block = document.getElementById("fill-page");
      block.style.display = "flex";
  }

function reportWindowSize() {
    const dish_border = document.querySelector("#dish-border");
    const dish_content = document.querySelector("#dish-extended");
    console.log(dish_border);
    let width = dish_border.offsetWidth;
    console.log(width);
    dish_content.offsetWidth = width;
}
  
document.addEventListener("click", dishByMousePos);
const shekel = "\u20AA";
let info=[];
getDishes();
window.onresize = reportWindowSize;

